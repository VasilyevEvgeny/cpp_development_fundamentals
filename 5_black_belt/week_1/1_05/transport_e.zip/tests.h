#pragma once

void RunAllTests();
